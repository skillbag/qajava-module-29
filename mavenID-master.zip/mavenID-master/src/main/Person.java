public class Person {
    public static boolean isTeenager(int age) {
        boolean result;
        if (age <= 19 && age >= 13) {
            return true;
        } else {
            return false;
        }
    }
}
